package com.example.smanagement.dto;

public class StudentDetails {

	int id;
	
	String name;
	
	int rollno;
	
	int clas;
	
	int math;
	
    int science;
	
	int english;
	
	int history;
	
	public StudentDetails(int id, String name, int rollno, int clas, int math, int science, int english, int history) {
		super();
		this.id = id;
		this.name = name;
		this.rollno = rollno;
		this.clas = clas;
		this.math = math;
		this.science = science;
		this.english = english;
		this.history = history;
	} 

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRollno() {
		return rollno;
	}

	public void setRollno(int rollno) {
		this.rollno = rollno;
	}

	public int getClas() {
		return clas;
	}

	public void setClas(int clas) {
		this.clas = clas;
	}

	public int getMath() {
		return math;
	}

	public void setMath(int math) {
		this.math = math;
	}

	public int getScience() {
		return science;
	}

	public void setScience(int science) {
		this.science = science;
	}

	public int getEnglish() {
		return english;
	}

	public void setEnglish(int english) {
		this.english = english;
	}

	public int getHistory() {
		return history;
	}

	public void setHistory(int history) {
		this.history = history;
	}
}
