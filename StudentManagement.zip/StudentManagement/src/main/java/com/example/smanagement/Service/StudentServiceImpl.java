package com.example.smanagement.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.smanagement.Model.Student;
import com.example.smanagement.Model.StudentMarks;
import com.example.smanagement.Repository.StudentMarksRepository;
import com.example.smanagement.Repository.StudentRepository;
import com.example.smanagement.dto.StudentDetails;

@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentMarksRepository studentmarks;
	
	@Autowired
	 StudentRepository sturepo;
	
	
	public void saveStudentDetails(StudentDetails studentdetails) {
		// TODO Auto-generated method stub
		
		Student student=new Student();
		student.setId(studentdetails.getId());
		student.setName(studentdetails.getName());
		student.setRollno(studentdetails.getRollno());
		student.setClas(studentdetails.getClas());
		
		int add=studentdetails.getEnglish()+ studentdetails.getHistory()+studentdetails.getMath()+studentdetails.getScience();
		
		float per=add/4;
		
		StudentMarks marks=new StudentMarks();
		
		marks.setPercent(per);
		marks.setEnglish(studentdetails.getEnglish());
		marks.setHistory(studentdetails.getHistory());
		marks.setMath(studentdetails.getMath());
		marks.setScience(studentdetails.getScience());
		marks.setRollno(studentdetails.getRollno());
		
		sturepo.save(student);
		studentmarks.save(marks);
		
	}

}
