package com.example.smanagement.Service;

import org.springframework.stereotype.Service;

import com.example.smanagement.dto.StudentDetails;

@Service
public interface StudentService {

	public static void saveStudentDetails(StudentDetails studentdetails) {
		// TODO Auto-generated method stub
		
	}
	
}
