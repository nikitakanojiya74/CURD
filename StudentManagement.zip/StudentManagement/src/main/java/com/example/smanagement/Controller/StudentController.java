package com.example.smanagement.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.smanagement.Model.StudentMarks;
import com.example.smanagement.Service.StudentService;
import com.example.smanagement.dto.StudentDetails;

@RestController
public class StudentController {
	
	@Autowired
	StudentService studentService;

	@PostMapping("/student/save")
	public String saveStudent(@RequestBody StudentDetails studentdetails) {
		try {
			StudentService.saveStudentDetails(studentdetails);
			
			
		}catch(Exception e) {
			
			return"Failed";
		}
		
		return"Success";
		
	}
	
	
	@PostMapping("/student/get/{rollno}")
	 public StudentMarks getStudentDetails(@PathVariable int rollno) {
		return null;
		
		 
	 }
}
